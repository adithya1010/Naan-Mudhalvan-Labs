'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

def merge_lists(list1, list2):
    list3=[]
    for i in range(0, len(list1)):
        list3.append(list1[i])
    for i in range(0, len(list2)):
        list3.append(list2[i])
    n = len(list3)
    for i in range(0, n):
        for j in range(0, n-i-1):
            if list3[j]>list3[j+1]:
                temp = list3[j]
                list3[j] = list3[j+1]
                list3[j+1]= temp
    return list3
list1 = [1,2,3,4]
list2=[4,3,2,1]
print(merge_lists(list1,list2))


